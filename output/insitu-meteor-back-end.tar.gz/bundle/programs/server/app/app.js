var require = meteorInstall({"imports":{"startup":{"router":{"api.js":["busboy","../../api/models.js","../../api/collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/startup/router/api.js                                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Busboy;module.import("busboy",{"default":function(v){Busboy=v}});var Models;module.import("../../api/models.js",{"Models":function(v){Models=v}});var Collections;module.import("../../api/collections.js",{"Collections":function(v){Collections=v}});
                                                                                                                 //
                                                                                                                 // 3
                                                                                                                 // 4
                                                                                                                 //
Router.route("/api/upload", { where: "server" }).get(function (req, res) {                                       // 6
    res.writeHead(200, { Connection: 'close' });                                                                 // 8
    res.end("\n            <html>\n                <head>\n                </head>\n                <body>\n                    <form method=\"POST\" enctype=\"multipart/form-data\">\n                        <input type=\"text\" name=\"textfield\"><br>\n                        <input type=\"file\" name=\"filefield\"><br>\n                        <input type=\"submit\">\n                    </form>\n                </body>\n            </html>\n        ");
}).post(function (req, res) {                                                                                    // 22
    var busboy = new Busboy({                                                                                    // 24
        headers: req.headers                                                                                     // 25
    });                                                                                                          // 24
                                                                                                                 //
    busboy.on('file', function (fieldname, file, filename, encoding, mimetype) {                                 // 28
        console.log('File [' + fieldname + ']: filename: ' + filename + ', encoding: ' + encoding + ', mimetype: ' + mimetype);
                                                                                                                 //
        file.on('data', function (data) {                                                                        // 31
            console.log('File [' + fieldname + '] got ' + data.length + ' bytes');                               // 32
        });                                                                                                      // 33
                                                                                                                 //
        file.on('end', function () {                                                                             // 35
            console.log('File [' + fieldname + '] Finished');                                                    // 36
        });                                                                                                      // 37
    });                                                                                                          // 38
                                                                                                                 //
    busboy.on('field', function (fieldname, value) {                                                             // 40
        console.log('Field [' + fieldname + ']: value: ' + value);                                               // 41
    });                                                                                                          // 42
                                                                                                                 //
    busboy.on('finish', function () {                                                                            // 44
        console.log('Done parsing form!');                                                                       // 45
                                                                                                                 //
        res.writeHead(303, { Connection: 'close', Location: '/api/upload' });                                    // 47
        res.end();                                                                                               // 48
    });                                                                                                          // 49
                                                                                                                 //
    req.pipe(busboy);                                                                                            // 51
});                                                                                                              // 52
                                                                                                                 //
Router.route("/api/models", { where: "server" }).get(function (req, res) {                                       // 54
    res.writeHead(200, {                                                                                         // 56
        "Content-Type": "application/json"                                                                       // 57
    });                                                                                                          // 56
                                                                                                                 //
    res.end(JSON.stringify(Models.find({}).fetch()));                                                            // 60
});                                                                                                              // 61
                                                                                                                 //
Router.route("/api/collections", { where: "server" }).get(function (req, res) {                                  // 63
    var temp = {};                                                                                               // 65
    var collections = [];                                                                                        // 66
    //let user = Accounts.findUserByEmail("testtest@test.com");                                                  // 67
    var user = Accounts.findUserByEmail("tim@landscaping.co.uk");                                                // 68
                                                                                                                 //
    var query = {                                                                                                // 70
        owner: user._id                                                                                          // 71
    };                                                                                                           // 70
                                                                                                                 //
    if (req.query.owner) {                                                                                       // 74
        query = {                                                                                                // 75
            owner: req.query.owner                                                                               // 76
        };                                                                                                       // 75
    }                                                                                                            // 78
                                                                                                                 //
    var models = Models.find(query).fetch();                                                                     // 80
                                                                                                                 //
    models.forEach(function (model) {                                                                            // 82
        if (model.collection) {                                                                                  // 83
            if (temp[model.collection._id]) {                                                                    // 84
                temp[model.collection._id].models.push(model);                                                   // 85
            } else {                                                                                             // 86
                temp[model.collection._id] = {                                                                   // 87
                    name: model.collection.name,                                                                 // 88
                    models: [model]                                                                              // 89
                };                                                                                               // 87
            }                                                                                                    // 93
        }                                                                                                        // 94
    });                                                                                                          // 95
                                                                                                                 //
    for (var key in meteorBabelHelpers.sanitizeForInObject(temp)) {                                              // 97
        collections.push(temp[key]);                                                                             // 98
    }                                                                                                            // 99
                                                                                                                 //
    res.writeHead(200, {                                                                                         // 101
        "Content-Type": "application/json"                                                                       // 102
    });                                                                                                          // 101
                                                                                                                 //
    res.end(JSON.stringify(collections));                                                                        // 105
});                                                                                                              // 106
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"api":{"collections.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/collections.js                                                                                    //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Collections:function(){return Collections}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                                 // 2
                                                                                                                 //
var Collections = new Mongo.Collection("collections");                                                           // 4
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 6
    Meteor.publish("Collections", function () {                                                                  // 7
        return Collections.find();                                                                               // 8
    });                                                                                                          // 9
}                                                                                                                // 10
                                                                                                                 //
                                                                                                                 // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"models.js":["meteor/mongo","./collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/models.js                                                                                         //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Models:function(){return Models},SaveModelMaterial:function(){return SaveModelMaterial}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});var Collections;module.import("./collections.js",{"Collections":function(v){Collections=v}});
                                                                                                                 // 2
                                                                                                                 //
var Models = new Mongo.Collection("models", {                                                                    // 4
    transform: function () {                                                                                     // 5
        function transform(document) {                                                                           // 4
            document.collection = Collections.findOne({                                                          // 6
                _id: document.collection                                                                         // 7
            });                                                                                                  // 6
                                                                                                                 //
            return document;                                                                                     // 10
        }                                                                                                        // 11
                                                                                                                 //
        return transform;                                                                                        // 4
    }()                                                                                                          // 4
});                                                                                                              // 4
                                                                                                                 //
function SaveModelMaterial(id, original, params) {                                                               // 14
    var material = {                                                                                             // 15
        name: original.name,                                                                                     // 16
        map: params.map || original.map,                                                                         // 17
        envMap: params.envMap || original.envMap,                                                                // 18
        bumpMap: params.bumpMap || original.bumpMap,                                                             // 19
        typeMap: params.typeMap || original.typeMap || "none",                                                   // 20
        color: params.color || original.color,                                                                   // 21
        specular: params.specular || original.specular,                                                          // 22
        transparent: params.transparent || original.transparent,                                                 // 23
        opacity: params.opacity || original.opacity,                                                             // 24
        reflectivity: params.reflectivity || original.reflectivity,                                              // 25
        shininess: params.shininess || original.shininess,                                                       // 26
        bumpScale: params.bumpScale || original.bumpScale,                                                       // 27
        preset: params.name || ''                                                                                // 28
    };                                                                                                           // 15
                                                                                                                 //
    var model = Models.findOne({                                                                                 // 31
        "_id": id,                                                                                               // 32
        "materials.name": original.name                                                                          // 33
    });                                                                                                          // 31
                                                                                                                 //
    if (model) {                                                                                                 // 36
        for (var key in meteorBabelHelpers.sanitizeForInObject(model.materials)) {                               // 37
            if (model.materials.hasOwnProperty(key)) {                                                           // 38
                if (model.materials[key].name == original.name) {                                                // 39
                    model.materials[key] = material;                                                             // 40
                    break;                                                                                       // 41
                }                                                                                                // 42
            }                                                                                                    // 43
        }                                                                                                        // 44
                                                                                                                 //
        Models.update({                                                                                          // 46
            _id: id                                                                                              // 47
        }, {                                                                                                     // 46
            $set: {                                                                                              // 49
                materials: model.materials                                                                       // 50
            }                                                                                                    // 49
        });                                                                                                      // 48
    } else {                                                                                                     // 53
        Models.update({                                                                                          // 54
            _id: id                                                                                              // 55
        }, {                                                                                                     // 54
            $push: {                                                                                             // 57
                materials: material                                                                              // 58
            }                                                                                                    // 57
        });                                                                                                      // 56
    }                                                                                                            // 61
                                                                                                                 //
    return material;                                                                                             // 63
}                                                                                                                // 64
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 66
    Meteor.publish("Models", function () {                                                                       // 67
        return Models.find();                                                                                    // 68
    });                                                                                                          // 69
}                                                                                                                // 70
                                                                                                                 //
                                                                                                                 // 72
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"presets.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/presets.js                                                                                        //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Presets:function(){return Presets}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                                 // 2
                                                                                                                 //
var Presets = new Mongo.Collection("presets");                                                                   // 4
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 6
    Meteor.publish("Presets", function () {                                                                      // 7
        return Presets.find();                                                                                   // 8
    });                                                                                                          // 9
}                                                                                                                // 10
                                                                                                                 //
                                                                                                                 // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"upload.js":["fs","path","decompress",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/upload.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var fs;module.import("fs",{"default":function(v){fs=v}});var path;module.import("path",{"default":function(v){path=v}});var decompress;module.import("decompress",{"default":function(v){decompress=v}});
                                                                                                                 // 2
                                                                                                                 // 3
                                                                                                                 //
Meteor.startup(function () {                                                                                     // 5
    var root = process.env.PWD || Meteor.absolutePath;                                                           // 6
                                                                                                                 //
    UploadServer.init({                                                                                          // 8
        tmpDir: root + "/uploads/tmp",                                                                           // 9
        uploadDir: root + "/uploads",                                                                            // 10
        uploadUrl: "/upload/",                                                                                   // 11
        checkCreateDirectories: true,                                                                            // 12
        getDirectory: function () {                                                                              // 13
            function getDirectory(fileInfo, formData) {                                                          // 8
                switch (formData.method) {                                                                       // 14
                    case "preview":                                                                              // 15
                        return formData.folder + "/previews/";                                                   // 16
                    case "restore":                                                                              // 17
                        return "restore/";                                                                       // 18
                    default:                                                                                     // 19
                        var folder = "misc";                                                                     // 20
                                                                                                                 //
                        if (fileInfo.type.indexOf("application/") === 0) {                                       // 22
                            folder = "models";                                                                   // 23
                        }                                                                                        // 24
                                                                                                                 //
                        if (fileInfo.type.indexOf("image/") === 0) {                                             // 26
                            folder = "textures";                                                                 // 27
                        }                                                                                        // 28
                                                                                                                 //
                        if (formData.model) {                                                                    // 30
                            return formData.model + "/" + folder + "/";                                          // 31
                        }                                                                                        // 32
                                                                                                                 //
                        return "others/" + folder + "/";                                                         // 34
                }                                                                                                // 14
            }                                                                                                    // 36
                                                                                                                 //
            return getDirectory;                                                                                 // 8
        }(),                                                                                                     // 8
        getFileName: function () {                                                                               // 37
            function getFileName(fileInfo, formData) {                                                           // 8
                return fileInfo.name;                                                                            // 38
            }                                                                                                    // 39
                                                                                                                 //
            return getFileName;                                                                                  // 8
        }(),                                                                                                     // 8
        finished: function () {                                                                                  // 40
            function finished(fileInfo, formData) {                                                              // 8
                if (formData.model) {                                                                            // 41
                    var ext = fileInfo.url.split(".").pop();                                                     // 42
                                                                                                                 //
                    if (ext === "mtl") {                                                                         // 44
                        fs.readFile(root + "/uploads/" + fileInfo.path, function (err, data) {                   // 45
                            if (err) {                                                                           // 46
                                throw err;                                                                       // 47
                            }                                                                                    // 48
                                                                                                                 //
                            var mtl = data.toString().replace(/(map_Ka|map_Kd|map_Bump|bump) (.+)/g, function (match, p1, p2) {
                                if (p1 && p2) {                                                                  // 51
                                    p2 = p2.replace(/\\|\//g, "/");                                              // 52
                                    p2 = p2.split("/").pop();                                                    // 53
                                                                                                                 //
                                    return p1 + " upload/" + formData.model + "/textures/" + p2;                 // 55
                                }                                                                                // 56
                                                                                                                 //
                                return match;                                                                    // 58
                            });                                                                                  // 59
                                                                                                                 //
                            fs.writeFile(root + "/uploads/" + fileInfo.path, mtl, function (err, data) {         // 61
                                if (err) {                                                                       // 62
                                    throw err;                                                                   // 63
                                }                                                                                // 64
                            });                                                                                  // 65
                        });                                                                                      // 66
                    }                                                                                            // 67
                } else if (formData.method == "restore") {                                                       // 68
                    decompress(root + "/uploads/" + fileInfo.path, root + "/uploads/" + fileInfo.subDirectory, {
                        filter: function () {                                                                    // 70
                            function filter(file) {                                                              // 69
                                return file.path.indexOf("__MACOSX") === -1;                                     // 71
                            }                                                                                    // 72
                                                                                                                 //
                            return filter;                                                                       // 69
                        }()                                                                                      // 69
                    }).then(function (files) {                                                                   // 69
                        fs.unlinkSync(root + "/uploads/" + fileInfo.path);                                       // 74
                                                                                                                 //
                        console.log(files);                                                                      // 76
                    });                                                                                          // 77
                }                                                                                                // 78
            }                                                                                                    // 79
                                                                                                                 //
            return finished;                                                                                     // 8
        }()                                                                                                      // 8
    });                                                                                                          // 8
});                                                                                                              // 81
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/accounts-base","../imports/api/models.js","../imports/api/presets.js","../imports/api/collections.js","../imports/startup/router/api.js","./upload.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Accounts;module.import("meteor/accounts-base",{"Accounts":function(v){Accounts=v}});var Models;module.import("../imports/api/models.js",{"Models":function(v){Models=v}});var Presets;module.import("../imports/api/presets.js",{"Presets":function(v){Presets=v}});var Collections;module.import("../imports/api/collections.js",{"Collections":function(v){Collections=v}});module.import("../imports/startup/router/api.js");module.import("./upload.js");
                                                                                                                 //
                                                                                                                 // 3
                                                                                                                 // 4
                                                                                                                 // 5
                                                                                                                 //
                                                                                                                 // 7
                                                                                                                 //
                                                                                                                 // 9
                                                                                                                 //
Meteor.methods({                                                                                                 // 11
    'serverIp': function () {                                                                                    // 12
        function serverIp() {                                                                                    // 12
            return this.connection.httpHeaders.host;                                                             // 13
        }                                                                                                        // 14
                                                                                                                 //
        return serverIp;                                                                                         // 12
    }()                                                                                                          // 12
});                                                                                                              // 11
                                                                                                                 //
Meteor.startup(function () {                                                                                     // 17
    WebApp.rawConnectHandlers.use(function (req, res, next) {                                                    // 18
        res.setHeader("Access-Control-Allow-Origin", "*");                                                       // 19
        return next();                                                                                           // 20
    });                                                                                                          // 21
                                                                                                                 //
    if (!Accounts.findUserByEmail("tim@landscaping.co.uk")) {                                                    // 23
        Accounts.createUser({                                                                                    // 24
            email: "tim@landscaping.co.uk",                                                                      // 25
            username: "tim",                                                                                     // 26
            password: "C3darNur$3ry"                                                                             // 27
        });                                                                                                      // 24
    }                                                                                                            // 29
                                                                                                                 //
    if (!Presets.findOne({})) {                                                                                  // 31
        Presets.insert({                                                                                         // 32
            name: "mt-m-metal",                                                                                  // 33
            typeMap: "metal",                                                                                    // 34
            color: "#222222",                                                                                    // 35
            specular: "#bbbbbb",                                                                                 // 36
            shininess: 75,                                                                                       // 37
            map: false,                                                                                          // 38
            envMap: true,                                                                                        // 39
            bumpMap: true,                                                                                       // 40
            bumpScale: 0.00015,                                                                                  // 41
            transparent: false,                                                                                  // 42
            opacity: 1,                                                                                          // 43
            reflectivity: 0.05                                                                                   // 44
        });                                                                                                      // 32
                                                                                                                 //
        Presets.insert({                                                                                         // 47
            name: "tg-glass",                                                                                    // 48
            typeMap: "glass",                                                                                    // 49
            color: "#444444",                                                                                    // 50
            specular: "#777777",                                                                                 // 51
            shininess: 100,                                                                                      // 52
            map: false,                                                                                          // 53
            envMap: true,                                                                                        // 54
            bumpMap: false,                                                                                      // 55
            bumpScale: 0,                                                                                        // 56
            transparent: true,                                                                                   // 57
            opacity: 0.5,                                                                                        // 58
            reflectivity: 0.25                                                                                   // 59
        });                                                                                                      // 47
    }                                                                                                            // 61
});                                                                                                              // 62
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/upload.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
