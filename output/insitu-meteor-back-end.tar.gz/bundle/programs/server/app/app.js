var require = meteorInstall({"imports":{"startup":{"router":{"api.js":["../../api/models.js","../../api/collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/startup/router/api.js                                                                     //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var Models;module.import("../../api/models.js",{"Models":function(v){Models=v}});var Collections;module.import("../../api/collections.js",{"Collections":function(v){Collections=v}});
                                                                                                     // 2
                                                                                                     //
Router.route("/api/models", { where: "server" }).get(function (req, res) {                           // 4
    res.writeHead(200, {                                                                             // 6
        "Content-Type": "application/json"                                                           // 7
    });                                                                                              // 6
                                                                                                     //
    res.end(JSON.stringify(Models.find({}).fetch()));                                                // 10
});                                                                                                  // 11
                                                                                                     //
Router.route("/api/collections", { where: "server" }).get(function (req, res) {                      // 13
    var temp = {};                                                                                   // 15
    var collections = [];                                                                            // 16
    var user = Accounts.findUserByEmail("tim@landscaping.co.uk");                                    // 17
                                                                                                     //
    var query = {                                                                                    // 19
        owner: user._id                                                                              // 20
    };                                                                                               // 19
                                                                                                     //
    if (req.query.owner) {                                                                           // 23
        query = {                                                                                    // 24
            owner: req.query.owner                                                                   // 25
        };                                                                                           // 24
    }                                                                                                // 27
                                                                                                     //
    var models = Models.find(query).fetch();                                                         // 29
                                                                                                     //
    models.forEach(function (model) {                                                                // 31
        if (model.collection) {                                                                      // 32
            if (temp[model.collection._id]) {                                                        // 33
                temp[model.collection._id].models.push(model);                                       // 34
            } else {                                                                                 // 35
                temp[model.collection._id] = {                                                       // 36
                    name: model.collection.name,                                                     // 37
                    models: [model]                                                                  // 38
                };                                                                                   // 36
            }                                                                                        // 42
        }                                                                                            // 43
    });                                                                                              // 44
                                                                                                     //
    for (var key in temp) {                                                                          // 46
        collections.push(temp[key]);                                                                 // 47
    }                                                                                                // 48
                                                                                                     //
    res.writeHead(200, {                                                                             // 50
        "Content-Type": "application/json"                                                           // 51
    });                                                                                              // 50
                                                                                                     //
    res.end(JSON.stringify(collections));                                                            // 54
});                                                                                                  // 55
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"api":{"collections.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/collections.js                                                                        //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Collections:function(){return Collections}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                     // 2
                                                                                                     //
var Collections = new Mongo.Collection("collections");                                               // 4
                                                                                                     //
if (Meteor.isServer) {                                                                               // 6
    Meteor.publish("Collections", function () {                                                      // 7
        return Collections.find();                                                                   // 8
    });                                                                                              // 9
}                                                                                                    // 10
                                                                                                     //
                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"models.js":["meteor/mongo","./collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/models.js                                                                             //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Models:function(){return Models},SaveModelMaterial:function(){return SaveModelMaterial}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});var Collections;module.import("./collections.js",{"Collections":function(v){Collections=v}});
                                                                                                     // 2
                                                                                                     //
var Models = new Mongo.Collection("models", {                                                        // 4
    transform: function transform(document) {                                                        // 5
        document.collection = Collections.findOne({                                                  // 6
            _id: document.collection                                                                 // 7
        });                                                                                          // 6
                                                                                                     //
        return document;                                                                             // 10
    }                                                                                                // 11
});                                                                                                  // 4
                                                                                                     //
function SaveModelMaterial(id, original, params) {                                                   // 14
    var material = {                                                                                 // 15
        name: original.name,                                                                         // 16
        map: params.map || original.map,                                                             // 17
        envMap: params.envMap || original.envMap,                                                    // 18
        bumpMap: params.bumpMap || original.bumpMap,                                                 // 19
        typeMap: params.typeMap || original.typeMap || "none",                                       // 20
        color: params.color || original.color,                                                       // 21
        specular: params.specular || original.specular,                                              // 22
        transparent: params.transparent || original.transparent,                                     // 23
        opacity: params.opacity || original.opacity,                                                 // 24
        reflectivity: params.reflectivity || original.reflectivity,                                  // 25
        shininess: params.shininess || original.shininess,                                           // 26
        bumpScale: params.bumpScale || original.bumpScale,                                           // 27
        preset: params.name || ''                                                                    // 28
    };                                                                                               // 15
                                                                                                     //
    var model = Models.findOne({                                                                     // 31
        "_id": id,                                                                                   // 32
        "materials.name": original.name                                                              // 33
    });                                                                                              // 31
                                                                                                     //
    if (model) {                                                                                     // 36
        for (var key in model.materials) {                                                           // 37
            if (model.materials.hasOwnProperty(key)) {                                               // 38
                if (model.materials[key].name == original.name) {                                    // 39
                    model.materials[key] = material;                                                 // 40
                    break;                                                                           // 41
                }                                                                                    // 42
            }                                                                                        // 43
        }                                                                                            // 44
                                                                                                     //
        Models.update({                                                                              // 46
            _id: id                                                                                  // 47
        }, {                                                                                         // 46
            $set: {                                                                                  // 49
                materials: model.materials                                                           // 50
            }                                                                                        // 49
        });                                                                                          // 48
    } else {                                                                                         // 53
        Models.update({                                                                              // 54
            _id: id                                                                                  // 55
        }, {                                                                                         // 54
            $push: {                                                                                 // 57
                materials: material                                                                  // 58
            }                                                                                        // 57
        });                                                                                          // 56
    }                                                                                                // 61
                                                                                                     //
    return material;                                                                                 // 63
}                                                                                                    // 64
                                                                                                     //
if (Meteor.isServer) {                                                                               // 66
    Meteor.publish("Models", function () {                                                           // 67
        return Models.find();                                                                        // 68
    });                                                                                              // 69
}                                                                                                    // 70
                                                                                                     //
                                                                                                     // 72
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"presets.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/presets.js                                                                            //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Presets:function(){return Presets}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                     // 2
                                                                                                     //
var Presets = new Mongo.Collection("presets");                                                       // 4
                                                                                                     //
if (Meteor.isServer) {                                                                               // 6
    Meteor.publish("Presets", function () {                                                          // 7
        return Presets.find();                                                                       // 8
    });                                                                                              // 9
}                                                                                                    // 10
                                                                                                     //
                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"upload.js":["fs",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/upload.js                                                                                  //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var fs;module.import("fs",{"default":function(v){fs=v}});                                            // 1
                                                                                                     //
Meteor.startup(function () {                                                                         // 3
    var root = process.env.PWD || "/Projects/Web/insitu-back";                                       // 4
                                                                                                     //
    UploadServer.init({                                                                              // 6
        tmpDir: root + "/uploads/tmp",                                                               // 7
        uploadDir: root + "/uploads",                                                                // 8
        checkCreateDirectories: true,                                                                // 9
        getDirectory: function getDirectory(fileInfo, formData) {                                    // 10
            switch (formData.method) {                                                               // 11
                case "preview":                                                                      // 12
                    return formData.folder + "/previews/";                                           // 13
                default:                                                                             // 14
                    var folder = "misc";                                                             // 15
                                                                                                     //
                    if (fileInfo.type.indexOf("application/") === 0) {                               // 17
                        folder = "models";                                                           // 18
                    }                                                                                // 19
                                                                                                     //
                    if (fileInfo.type.indexOf("image/") === 0) {                                     // 21
                        folder = "textures";                                                         // 22
                    }                                                                                // 23
                                                                                                     //
                    if (formData.model) {                                                            // 25
                        return formData.model + "/" + folder + "/";                                  // 26
                    }                                                                                // 27
                                                                                                     //
                    return "others/" + folder + "/";                                                 // 29
            }                                                                                        // 11
        },                                                                                           // 31
        finished: function finished(fileInfo, formData) {                                            // 32
            if (formData.model) {                                                                    // 33
                var ext = fileInfo.url.split(".").pop();                                             // 34
                                                                                                     //
                if (ext === "mtl") {                                                                 // 36
                    fs.readFile(root + "/uploads/" + fileInfo.path, function (err, data) {           // 37
                        if (err) {                                                                   // 38
                            throw err;                                                               // 39
                        }                                                                            // 40
                                                                                                     //
                        var mtl = data.toString().replace(/(map_Ka|map_Kd|map_Bump|bump) (.+)/g, function (match, p1, p2) {
                            if (p1 && p2) {                                                          // 43
                                p2 = p2.replace(/\\|\//g, "/");                                      // 44
                                p2 = p2.split("/").pop();                                            // 45
                                                                                                     //
                                return p1 + " upload/" + formData.model + "/textures/" + p2;         // 47
                            }                                                                        // 48
                                                                                                     //
                            return match;                                                            // 50
                        });                                                                          // 51
                                                                                                     //
                        fs.writeFile(root + "/uploads/" + fileInfo.path, mtl, function (err, data) {
                            if (err) {                                                               // 54
                                throw err;                                                           // 55
                            }                                                                        // 56
                        });                                                                          // 57
                    });                                                                              // 58
                }                                                                                    // 59
            }                                                                                        // 60
        }                                                                                            // 61
    });                                                                                              // 6
});                                                                                                  // 63
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/accounts-base","../imports/api/models.js","../imports/api/presets.js","../imports/api/collections.js","../imports/startup/router/api.js","./upload.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/main.js                                                                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var Accounts;module.import("meteor/accounts-base",{"Accounts":function(v){Accounts=v}});var Models;module.import("../imports/api/models.js",{"Models":function(v){Models=v}});var Presets;module.import("../imports/api/presets.js",{"Presets":function(v){Presets=v}});var Collections;module.import("../imports/api/collections.js",{"Collections":function(v){Collections=v}});module.import("../imports/startup/router/api.js");module.import("./upload.js");
                                                                                                     //
                                                                                                     // 3
                                                                                                     // 4
                                                                                                     // 5
                                                                                                     //
                                                                                                     // 7
                                                                                                     //
                                                                                                     // 9
                                                                                                     //
Meteor.startup(function () {                                                                         // 11
    WebApp.rawConnectHandlers.use(function (req, res, next) {                                        // 12
        res.setHeader("Access-Control-Allow-Origin", "*");                                           // 13
        return next();                                                                               // 14
    });                                                                                              // 15
                                                                                                     //
    if (!Accounts.findUserByEmail("tim@landscaping.co.uk")) {                                        // 17
        Accounts.createUser({                                                                        // 18
            email: "tim@landscaping.co.uk",                                                          // 19
            username: "tim",                                                                         // 20
            password: "C3darNur$3ry"                                                                 // 21
        });                                                                                          // 18
    }                                                                                                // 23
                                                                                                     //
    if (!Presets.findOne({})) {                                                                      // 25
        Presets.insert({                                                                             // 26
            name: "mt-m-metal",                                                                      // 27
            typeMap: "metal",                                                                        // 28
            color: "#222222",                                                                        // 29
            specular: "#bbbbbb",                                                                     // 30
            shininess: 75,                                                                           // 31
            map: false,                                                                              // 32
            envMap: true,                                                                            // 33
            bumpMap: true,                                                                           // 34
            bumpScale: 0.00015,                                                                      // 35
            transparent: false,                                                                      // 36
            opacity: 1,                                                                              // 37
            reflectivity: 0.05                                                                       // 38
        });                                                                                          // 26
                                                                                                     //
        Presets.insert({                                                                             // 41
            name: "tg-glass",                                                                        // 42
            typeMap: "glass",                                                                        // 43
            color: "#444444",                                                                        // 44
            specular: "#777777",                                                                     // 45
            shininess: 100,                                                                          // 46
            map: false,                                                                              // 47
            envMap: true,                                                                            // 48
            bumpMap: false,                                                                          // 49
            bumpScale: 0,                                                                            // 50
            transparent: true,                                                                       // 51
            opacity: 0.5,                                                                            // 52
            reflectivity: 0.25                                                                       // 53
        });                                                                                          // 41
    }                                                                                                // 55
});                                                                                                  // 56
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/upload.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
