var require = meteorInstall({"imports":{"startup":{"router":{"api.js":["../../api/models.js","../../api/collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/startup/router/api.js                                                                     //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var Models;module.import("../../api/models.js",{"Models":function(v){Models=v}});var Collections;module.import("../../api/collections.js",{"Collections":function(v){Collections=v}});
                                                                                                     // 2
                                                                                                     //
Router.route("/api/models", { where: "server" }).get(function (req, res) {                           // 4
    res.writeHead(200, {                                                                             // 6
        "Content-Type": "application/json"                                                           // 7
    });                                                                                              // 6
                                                                                                     //
    res.end(JSON.stringify(Models.find({}).fetch()));                                                // 10
});                                                                                                  // 11
                                                                                                     //
Router.route("/api/collections", { where: "server" }).get(function (req, res) {                      // 13
    var temp = {};                                                                                   // 15
    var collections = [];                                                                            // 16
    var user = Accounts.findUserByEmail("testtest@test.com");                                        // 17
    //let user = Accounts.findUserByEmail("tim@landscaping.co.uk");                                  //
                                                                                                     //
    var query = {                                                                                    // 20
        owner: user._id                                                                              // 21
    };                                                                                               // 20
                                                                                                     //
    if (req.query.owner) {                                                                           // 24
        query = {                                                                                    // 25
            owner: req.query.owner                                                                   // 26
        };                                                                                           // 25
    }                                                                                                // 28
                                                                                                     //
    var models = Models.find(query).fetch();                                                         // 30
                                                                                                     //
    models.forEach(function (model) {                                                                // 32
        if (model.collection) {                                                                      // 33
            if (temp[model.collection._id]) {                                                        // 34
                temp[model.collection._id].models.push(model);                                       // 35
            } else {                                                                                 // 36
                temp[model.collection._id] = {                                                       // 37
                    name: model.collection.name,                                                     // 38
                    models: [model]                                                                  // 39
                };                                                                                   // 37
            }                                                                                        // 43
        }                                                                                            // 44
    });                                                                                              // 45
                                                                                                     //
    for (var key in temp) {                                                                          // 47
        collections.push(temp[key]);                                                                 // 48
    }                                                                                                // 49
                                                                                                     //
    res.writeHead(200, {                                                                             // 51
        "Content-Type": "application/json"                                                           // 52
    });                                                                                              // 51
                                                                                                     //
    res.end(JSON.stringify(collections));                                                            // 55
});                                                                                                  // 56
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"api":{"collections.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/collections.js                                                                        //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Collections:function(){return Collections}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                     // 2
                                                                                                     //
var Collections = new Mongo.Collection("collections");                                               // 4
                                                                                                     //
if (Meteor.isServer) {                                                                               // 6
    Meteor.publish("Collections", function () {                                                      // 7
        return Collections.find();                                                                   // 8
    });                                                                                              // 9
}                                                                                                    // 10
                                                                                                     //
                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"models.js":["meteor/mongo","./collections.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/models.js                                                                             //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Models:function(){return Models},SaveModelMaterial:function(){return SaveModelMaterial}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});var Collections;module.import("./collections.js",{"Collections":function(v){Collections=v}});
                                                                                                     // 2
                                                                                                     //
var Models = new Mongo.Collection("models", {                                                        // 4
    transform: function transform(document) {                                                        // 5
        document.collection = Collections.findOne({                                                  // 6
            _id: document.collection                                                                 // 7
        });                                                                                          // 6
                                                                                                     //
        return document;                                                                             // 10
    }                                                                                                // 11
});                                                                                                  // 4
                                                                                                     //
function SaveModelMaterial(id, original, params) {                                                   // 14
    var material = {                                                                                 // 15
        name: original.name,                                                                         // 16
        map: params.map || original.map,                                                             // 17
        envMap: params.envMap || original.envMap,                                                    // 18
        bumpMap: params.bumpMap || original.bumpMap,                                                 // 19
        typeMap: params.typeMap || original.typeMap || "none",                                       // 20
        color: params.color || original.color,                                                       // 21
        specular: params.specular || original.specular,                                              // 22
        transparent: params.transparent || original.transparent,                                     // 23
        opacity: params.opacity || original.opacity,                                                 // 24
        reflectivity: params.reflectivity || original.reflectivity,                                  // 25
        shininess: params.shininess || original.shininess,                                           // 26
        bumpScale: params.bumpScale || original.bumpScale,                                           // 27
        preset: params.name || ''                                                                    // 28
    };                                                                                               // 15
                                                                                                     //
    var model = Models.findOne({                                                                     // 31
        "_id": id,                                                                                   // 32
        "materials.name": original.name                                                              // 33
    });                                                                                              // 31
                                                                                                     //
    if (model) {                                                                                     // 36
        for (var key in model.materials) {                                                           // 37
            if (model.materials.hasOwnProperty(key)) {                                               // 38
                if (model.materials[key].name == original.name) {                                    // 39
                    model.materials[key] = material;                                                 // 40
                    break;                                                                           // 41
                }                                                                                    // 42
            }                                                                                        // 43
        }                                                                                            // 44
                                                                                                     //
        Models.update({                                                                              // 46
            _id: id                                                                                  // 47
        }, {                                                                                         // 46
            $set: {                                                                                  // 49
                materials: model.materials                                                           // 50
            }                                                                                        // 49
        });                                                                                          // 48
    } else {                                                                                         // 53
        Models.update({                                                                              // 54
            _id: id                                                                                  // 55
        }, {                                                                                         // 54
            $push: {                                                                                 // 57
                materials: material                                                                  // 58
            }                                                                                        // 57
        });                                                                                          // 56
    }                                                                                                // 61
                                                                                                     //
    return material;                                                                                 // 63
}                                                                                                    // 64
                                                                                                     //
if (Meteor.isServer) {                                                                               // 66
    Meteor.publish("Models", function () {                                                           // 67
        return Models.find();                                                                        // 68
    });                                                                                              // 69
}                                                                                                    // 70
                                                                                                     //
                                                                                                     // 72
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"presets.js":["meteor/meteor","meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// imports/api/presets.js                                                                            //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
module.export({Presets:function(){return Presets}});var Meteor;module.import("meteor/meteor",{"Meteor":function(v){Meteor=v}});var Mongo;module.import("meteor/mongo",{"Mongo":function(v){Mongo=v}});
                                                                                                     // 2
                                                                                                     //
var Presets = new Mongo.Collection("presets");                                                       // 4
                                                                                                     //
if (Meteor.isServer) {                                                                               // 6
    Meteor.publish("Presets", function () {                                                          // 7
        return Presets.find();                                                                       // 8
    });                                                                                              // 9
}                                                                                                    // 10
                                                                                                     //
                                                                                                     // 12
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"upload.js":["fs","path",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/upload.js                                                                                  //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var fs;module.import("fs",{"default":function(v){fs=v}});var path;module.import("path",{"default":function(v){path=v}});
                                                                                                     // 2
                                                                                                     //
Meteor.startup(function () {                                                                         // 4
    var root = Meteor.absolutePath;                                                                  // 5
    //const root = process.env.PWD || "/Projects/Web/insitu-back";                                   //
                                                                                                     //
    UploadServer.init({                                                                              // 8
        tmpDir: root + "/uploads/tmp",                                                               // 9
        uploadDir: root + "/uploads",                                                                // 10
        checkCreateDirectories: true,                                                                // 11
        getDirectory: function getDirectory(fileInfo, formData) {                                    // 12
            switch (formData.method) {                                                               // 13
                case "preview":                                                                      // 14
                    return formData.folder + "/previews/";                                           // 15
                default:                                                                             // 16
                    var folder = "misc";                                                             // 17
                                                                                                     //
                    if (fileInfo.type.indexOf("application/") === 0) {                               // 19
                        folder = "models";                                                           // 20
                    }                                                                                // 21
                                                                                                     //
                    if (fileInfo.type.indexOf("image/") === 0) {                                     // 23
                        folder = "textures";                                                         // 24
                    }                                                                                // 25
                                                                                                     //
                    if (formData.model) {                                                            // 27
                        return formData.model + "/" + folder + "/";                                  // 28
                    }                                                                                // 29
                                                                                                     //
                    return "others/" + folder + "/";                                                 // 31
            }                                                                                        // 13
        },                                                                                           // 33
        finished: function finished(fileInfo, formData) {                                            // 34
            if (formData.model) {                                                                    // 35
                var ext = fileInfo.url.split(".").pop();                                             // 36
                                                                                                     //
                if (ext === "mtl") {                                                                 // 38
                    fs.readFile(root + "/uploads/" + fileInfo.path, function (err, data) {           // 39
                        if (err) {                                                                   // 40
                            throw err;                                                               // 41
                        }                                                                            // 42
                                                                                                     //
                        var mtl = data.toString().replace(/(map_Ka|map_Kd|map_Bump|bump) (.+)/g, function (match, p1, p2) {
                            if (p1 && p2) {                                                          // 45
                                p2 = p2.replace(/\\|\//g, "/");                                      // 46
                                p2 = p2.split("/").pop();                                            // 47
                                                                                                     //
                                return p1 + " upload/" + formData.model + "/textures/" + p2;         // 49
                            }                                                                        // 50
                                                                                                     //
                            return match;                                                            // 52
                        });                                                                          // 53
                                                                                                     //
                        fs.writeFile(root + "/uploads/" + fileInfo.path, mtl, function (err, data) {
                            if (err) {                                                               // 56
                                throw err;                                                           // 57
                            }                                                                        // 58
                        });                                                                          // 59
                    });                                                                              // 60
                }                                                                                    // 61
            }                                                                                        // 62
        }                                                                                            // 63
    });                                                                                              // 8
});                                                                                                  // 65
///////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/accounts-base","../imports/api/models.js","../imports/api/presets.js","../imports/api/collections.js","../imports/startup/router/api.js","./upload.js",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// server/main.js                                                                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
var Accounts;module.import("meteor/accounts-base",{"Accounts":function(v){Accounts=v}});var Models;module.import("../imports/api/models.js",{"Models":function(v){Models=v}});var Presets;module.import("../imports/api/presets.js",{"Presets":function(v){Presets=v}});var Collections;module.import("../imports/api/collections.js",{"Collections":function(v){Collections=v}});module.import("../imports/startup/router/api.js");module.import("./upload.js");
                                                                                                     //
                                                                                                     // 3
                                                                                                     // 4
                                                                                                     // 5
                                                                                                     //
                                                                                                     // 7
                                                                                                     //
                                                                                                     // 9
                                                                                                     //
Meteor.startup(function () {                                                                         // 11
    WebApp.rawConnectHandlers.use(function (req, res, next) {                                        // 12
        res.setHeader("Access-Control-Allow-Origin", "*");                                           // 13
        return next();                                                                               // 14
    });                                                                                              // 15
                                                                                                     //
    if (!Accounts.findUserByEmail("tim@landscaping.co.uk")) {                                        // 17
        Accounts.createUser({                                                                        // 18
            email: "tim@landscaping.co.uk",                                                          // 19
            username: "tim",                                                                         // 20
            password: "C3darNur$3ry"                                                                 // 21
        });                                                                                          // 18
    }                                                                                                // 23
                                                                                                     //
    if (!Presets.findOne({})) {                                                                      // 25
        Presets.insert({                                                                             // 26
            name: "mt-m-metal",                                                                      // 27
            typeMap: "metal",                                                                        // 28
            color: "#222222",                                                                        // 29
            specular: "#bbbbbb",                                                                     // 30
            shininess: 75,                                                                           // 31
            map: false,                                                                              // 32
            envMap: true,                                                                            // 33
            bumpMap: true,                                                                           // 34
            bumpScale: 0.00015,                                                                      // 35
            transparent: false,                                                                      // 36
            opacity: 1,                                                                              // 37
            reflectivity: 0.05                                                                       // 38
        });                                                                                          // 26
                                                                                                     //
        Presets.insert({                                                                             // 41
            name: "tg-glass",                                                                        // 42
            typeMap: "glass",                                                                        // 43
            color: "#444444",                                                                        // 44
            specular: "#777777",                                                                     // 45
            shininess: 100,                                                                          // 46
            map: false,                                                                              // 47
            envMap: true,                                                                            // 48
            bumpMap: false,                                                                          // 49
            bumpScale: 0,                                                                            // 50
            transparent: true,                                                                       // 51
            opacity: 0.5,                                                                            // 52
            reflectivity: 0.25                                                                       // 53
        });                                                                                          // 41
    }                                                                                                // 55
});                                                                                                  // 56
///////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/upload.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
